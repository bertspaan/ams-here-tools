import sys

from nagini.utils.geo import Point
from pygeodesy.sphericalTrigonometry import LatLon, nearestOn2


def get_lengths(points):
    d = []
    for ip in range(len(points)-1):
        p1 = Point(latitude=points[ip][0], longitude=points[ip][1])
        p2 = Point(latitude=points[ip+1][0], longitude=points[ip+1][1])

        d.append(p2.distance(p1))
    return d


# get the coordinate from the segment geometry and offset
def get_latlng_from_link_offset(shape_points, offset):

    SMALL_NUMBER = 0.000001
    if offset<SMALL_NUMBER:
        offset=SMALL_NUMBER
    elif offset>1.0-SMALL_NUMBER:
        offset=1.0-SMALL_NUMBER

    lengths = get_lengths(shape_points)
    tot_length = sum(lengths)

    offset_so_far = 0.0
    for ii in range(1, len(shape_points)):
        this_offset = lengths[ii-1]/tot_length
        #print offset_so_far,offset,offset_so_far+this_offset
        if offset>=offset_so_far and offset<=offset_so_far+this_offset:
            #then we just need to interpolate between this shape point ii-1 and ii
            distance_needed = (offset-offset_so_far)*tot_length
            segment_length = lengths[ii-1]

            frac_of_this_segment = distance_needed/segment_length
            delta_lat = (shape_points[ii][0]-shape_points[ii-1][0])*frac_of_this_segment
            delta_lng = (shape_points[ii][1]-shape_points[ii-1][1])*frac_of_this_segment
            return ( shape_points[ii-1][0]+delta_lat, shape_points[ii-1][1]+delta_lng)
        else:
            offset_so_far += this_offset
    print('getting lat long from offset -- weird failure!')
    print(offset)
    print(shape_points)
    print(lengths)
    print(offset_so_far,tot_length)
    return (0.0,0.0)


#p is a (lat,long) and segments are lat/longs
def closestSegment(p1, shape_points):

    BIG_NUM=1000000

    minimum=[]
    mindist =BIG_NUM
    mindiff =BIG_NUM
    threshold  =1
    seg_heading=999
    iwhile=0
    #jmt - I don't have any evidence that this while loop does anything (other than cause an infinite loop sometimes)
    # i can't remember the history of this
    while mindiff==BIG_NUM:
        for iseg in range(1,len(shape_points)):
            lp1 = shape_points[iseg-1]
            lp2 = shape_points[iseg]
            #diff = mapmatch.DistancePointLine(p1, lp1, lp2) #this was eric's way of doing it; he combined it with a check on angles
            #it looks for the smallest perp distance from the segment to the point
            #print 'debug',lp1,lp2,p1
            #this is the 'triangle side length' method ; is there a flaw to it? seems to work for me.

            LP1 = Point(latitude=lp1[0],longitude=lp1[1])
            P1 = Point(latitude=p1[0],longitude=p1[1])
            LP2 = Point(latitude=lp2[0],longitude=lp2[1])
            diff1 = LP1.distance(P1) + LP2.distance(P1) - LP1.distance(LP2)
            #diff1 = haversine( lp1[0],lp1[1], p1[0],p1[1])+haversine( lp2[0],lp2[1], p1[0],p1[1])-haversine( lp1[0],lp1[1], lp2[0],lp2[1])
            #print 'difference:',iseg,diff1
            if diff1<=mindiff:
                #seg_dist, seg_heading = mapmatch.distBearingBetweenPoints(lp2[0], lp2[1], lp1[0], lp1[1])
                mindist= 0.0#mapmatch.DistancePointLine(p1,lp1,lp2) #FIXME -- this is probably not used!
                minimum = [p1, iseg, mindist]
                mindiff=diff1
        if mindiff==BIG_NUM:
            print('Problem in maptools.py - still in the loop ', iwhile)
            print(p1)
            print(shape_points)
            sys.exit(1)
        iwhile+=1
    return minimum[1]-1


def get_offset( shape_points, lat , lng):

    lengths = get_lengths(shape_points)
    tot_length = sum(lengths)

    shape = [LatLon(q[0],q[1]) for q in shape_points]
    #project the lat/lon onto the shape_points
    # arguably this nearestOn2 operation should be put into closestSegmnet, not out here
    coord_on_shape = nearestOn2(LatLon(lat,lng),shape)[0]
    #print( 'OTools',lat,lng,coord_on_shape.lat,coord_on_shape.lon)
    closest_segment = closestSegment( (coord_on_shape.lat,coord_on_shape.lon), shape_points)
    offsetlength = 0.0
    for iseg in range(closest_segment):
        offsetlength += lengths[iseg]
    p1 = shape_points[closest_segment]
    p2 = shape_points[closest_segment+1]
    #print(closest_segment,p1,p2)
    suboffsetlength = coord_on_shape.alongTrackDistanceTo( LatLon(p1[0],p1[1]),LatLon(p2[0],p2[1]) )
    #print( Haversine.Haversine( p1[0],p1[1],p2[0],p2[1]),suboffsetlength)
    o=(suboffsetlength+offsetlength)/tot_length
    #print(o)
    return o
