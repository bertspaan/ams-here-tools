"""
Define utilities for dealing with chains of segments

    offset_on_chain: return offset on a chain, given a point on a segment in the chain
    shape_points: return the shape points of the chain in physical order
    is_inverted: given a segment, find out if the segment is inverted w.r.t. the chain direction
"""
import itertools
import math

from segment import TopologySegment


# convenience function for comparing coordinates (i.e. pairs in a tuple) with a tolerance
def cequals(a,b):
    TOL = 0.0000001

    e1 = math.isclose(a[0], b[0], abs_tol=TOL)
    e2 = math.isclose(a[1], b[1], abs_tol=TOL)

    return (e1 and e2)


class SegmentChain:
    def __init__(self, segment_list):
        # segment_list should be a list of TopologySegment
        self.segment_list = segment_list

    def offset_on_chain(self, segment, offset_in_dot):
        """
        Input: TopologySegment segment, float offset_in_dot
        offset_in_dot is the offset on segment in the direction of travel; this is what comes from the map-matcher

        Return the offset of with respect to the start of this SegmentChain of the position defined by the above
        """

        if len(self.segment_list) == 1:
            if self.segment_list[0]!=segment:
                raise ValueError('offset_on_chain: input segment is not on chain!')
            # in this simple case, the map-matcher has already calculated the offset for us
            return offset_in_dot

        lengths = [_.length() for _ in self.segment_list]
        total_length = sum(lengths)

        length_so_far = 0.0
        for seg_p in zip(self.segment_list, lengths):
            seg, L = seg_p
            if seg == segment:
                offset = (length_so_far + offset_in_dot*L) / total_length
                return offset
            else:
                length_so_far += L

        return None

    def shape_points(self, return_nodes=False):
        """
        Return a list of shape points for this chain, in the correct physical order
        """

        # implementation note:
        # I am copying exactly my old implementation
        # I'm not sure I like how it depends on cequals() but for now just reimplement it "as good" as it was before

        pp = []
        slindex = []
        internal_node_coords = []  # coordinates of internal nodes, if the user wants those
        for ilink, link in enumerate(self.segment_list):
            if ilink>0:
                if lastlink == link:
                    print('WARNING -- output of SegmentChain::shape_points() is not reliable when there is a U-turn')
                    return None

            points = link.shape_points()
            lastlink = TopologySegment(link.pid, link.sid)

            # this block of ifs builds a chain of shape points that run from one end of the superlink to the other
            len_pp = len(pp)
            if len_pp == 0:
                pp.append(points)
            elif len_pp == 1:
                p1 = pp[0]
                if cequals(p1[-1], points[0]):
                    pp.append(points)
                    internal_node_coords.append(p1[-1])
                elif cequals(p1[0],points[0]):
                    p1 = p1[::-1]
                    pp = [p1, points]
                    internal_node_coords.append( p1[-1]) #now that p1 is flipped
                elif cequals(p1[-1],points[-1]):
                    points = points[::-1]
                    pp = [p1, points]
                    internal_node_coords.append( p1[-1])
                elif cequals(p1[0],points[-1]):
                    p1 = p1[::-1]
                    points=points[::-1]
                    pp=[p1,points]
                    internal_node_coords.append( p1[-1]) #now that p1 is flipped
                else:
                    print('get_chain_shape_points problem!')
                    print(chain)
                    print(p1[0],p1[-1])
                    print(points[0],points[-1])
            elif len_pp > 1:
                p1 = pp[-1]
                if cequals(p1[-1], points[0]):
                    pp.append(points)
                    internal_node_coords.append( p1[-1])
                elif cequals(p1[-1], points[-1]):
                    points = points[::-1]
                    pp.append(points)
                    internal_node_coords.append(p1[-1])
            slindex.extend([ilink]*len(points))

        flattened = list(itertools.chain(*pp))
        superlink_points = [flattened[0]] #will hold all of the shape points
        # indices=[slindex[0]] #right now this is not used, so comment it out
        #remove duplicate shape points (at nodes)
        for i in range(1,len(flattened)):
            if not cequals(flattened[i], superlink_points[len(superlink_points)-1]):
                superlink_points.append(flattened[i])
                #indices.append( slindex[i]) # can uncomment if we start using this
        # we used to have logic to compute a "reverseme" condition
        # in this way we made the link chain use the same convention as normal links, where
        # the "start" of the link is always the SW coordinate.
        # however with RIB we no longer use that convention, so i guess i will not do it

        if return_nodes:
            return superlink_points, internal_node_coords
        return superlink_points


    def is_inverted(self, segment):
        """
        Determine if the input segment is inverted w.r.t. the chain direction
        """

        # as noted elsewhere, for now I exactly preserve the logic I had implemented previously,
        # even if there might be room for improvement

        for iseg,seg in enumerate(self.segment_list):
            if seg==segment: #found the segment of interest
                if iseg==0:
                    # this logic assumes that the chain is more than 1 segment long

                    #need to compare nodes of seg with nodes of iseg+1
                    shape_points0 = seg.shape_points()
                    shape_points1 = self.segment_list[1].shape_points()
                    if cequals(shape_points0[-1], shape_points1[0]) or cequals(shape_points0[-1], shape_points1[-1]):
                        inverted = False
                    elif cequals(shape_points0[0], shape_points1[0]) or cequals(shape_points0[0], shape_points1[-1]):
                        inverted = True
                    else:
                        assert False, 'problem in is_inverted (1)'
                else:
                    shape_points0 = self.segment_list[iseg-1].shape_points()   #the previous segment
                    shape_points1 = seg.shape_points()
                    #case: shared node is start node of shape_points1 --> NOT INVERTED
                    #case: shared node is end node of shape_points1 --> INVERTED
                    if cequals(shape_points1[0], shape_points0[0]) or cequals(shape_points1[0], shape_points0[-1]):
                        inverted = False
                    elif cequals(shape_points1[-1], shape_points0[0]) or cequals(shape_points1[-1], shape_points0[-1]):
                        inverted = True
                    else:
                        #errormsg = 'problem in is_inverted %d,%d %d,%d' %(sequence[iseg-1][0],sequence[iseg-1][1],seg[0],seg[1])
                        assert False, 'problem in is_inverted (2'
                return inverted
        return None


def test1():
    sl = [TopologySegment(20095974,463602083), TopologySegment(20095974,401451358)]
    sc = SegmentChain(sl)

    print([q.length() for q in sl])

    print( sc.offset_on_chain(TopologySegment(20095974,401451358), 0.01))
    print( sc.offset_on_chain(TopologySegment(20095974,401451358), 0.99))

def test2():
    sl = [TopologySegment(20095974,463602083), TopologySegment(20095974,401451358)]
    sc = SegmentChain(sl)
    p = sc.shape_points()

    s = ','.join( [str(q[0])+','+str(q[1]) for q in p] )
    print(s)


def test4():
    s1 = TopologySegment(20095974,495758115)
    s2 = TopologySegment(20095974,465574224)
    s3 = TopologySegment(20095974,478099748)

    sl = [s1,s2,s3]

    #invert the order (optional)
    #sl = sl[::-1]

    sc = SegmentChain(sl)

    p = sc.shape_points()
    print( ','.join([str(q[0]) + ',' + str(q[1]) for q in p]) )

    for seg in sl:
        print(str(seg), sc.is_inverted(seg))

if __name__=='__main__':
    test4()
