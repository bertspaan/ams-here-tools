import datetime
from segment import CatalogAccess
from nagini.utils.tiling import tile_id_from_coordinate, Point,bounding_box_from_tile_id,tile_ids_from_bounding_box
import pandas as pd


class WeatherAccess(CatalogAccess):
    """
    Base class for weather access
    """
    _CATALOG = {}
    _CATALOG['NA'] = 'hrn:here:data:::live-weather-archive-na'
    _CATALOG['EU'] = 'hrn:here:data:::live-weather-archive-eu'

    _catalog = {}
    _catalog['NA'] = CatalogAccess._olp.catalog_by_hrn(_CATALOG['NA'])
    _catalog['EU'] = CatalogAccess._olp.catalog_by_hrn(_CATALOG['EU'])

    def _read_data(self,layer,schema,pid,version):
        return super().read_data( layer,schema,pid,version)


class WeatherTimestampReader(WeatherAccess):
    """
    Provide access to the Weather Archive Timestamp->Version index
    For most use cases, user does not need to worry about this class -- just use WeatherReader
    """
    # key is EU or NA
    timestamp_version_list = {}

    def __init__(self):

        for region in WeatherAccess._CATALOG:
            timestamp_layer = WeatherAccess._catalog[region].layer_by_id('timestamp-index')
            ts_data = timestamp_layer.read_partitions(['index'])

            ts_blob = next(ts_data)
            self.timestamp_version_list[region] = ts_blob.decode().splitlines()

            self.timestamp_version_list[region] = [self.parse_pairs(q) for q in self.timestamp_version_list[region]]

    def earliest(self, region):
        """Return the timestamp of the earlier version"""
        return self.timestamp_version_list[region][0][0].strftime('%m/%d/%Y %H:%M:%S')

    def parse_pairs(self, q):
        ts = datetime.datetime.strptime(q.split(',')[0], '%m/%d/%Y %H:%M:%S')
        version = int(q.split(',')[1])
        return (ts,version)

    def find_version(self, ts0, region):
        """Given the input timestamp (datetime), return the corresponding version"""
        # brute force search for now ; obviously a binary tree would be faster for repeated queries (bisect)
        for i in range(len(self.timestamp_version_list[region])-1):
            if (ts0 >= self.timestamp_version_list[region][i][0]) and (ts0 <= self.timestamp_version_list[region][i+1][0]):
                dt1 = ts0 - self.timestamp_version_list[region][i][0]
                dt2 = self.timestamp_version_list[region][i+1][0] - ts0
                if dt1 < dt2:
                    return self.timestamp_version_list[region][i][1]
                else:
                    return self.timestamp_version_list[region][i+1][1]
        return None


class WeatherReader(WeatherAccess):
    """
    Class to access archived weather data
    For most use cases, this is the only class the user needs. The timestamp index is accessed behind the scenes
    by this class.
    """
    _layer = {}
    _layer['EU'] = WeatherAccess._catalog['EU'].layer_by_id('archived-data')
    _layer['NA'] = WeatherAccess._catalog['NA'].layer_by_id('archived-data')
    _schema = {}
    _schema['EU'] = _layer['EU'].read_schema()
    _schema['NA'] = _layer['NA'].read_schema()
    partition_cache = {}  # key is (version, tile8)

    _timestamp_decoder = WeatherTimestampReader()

    verbose = False

    def _get_weather(self, tile8, version, region):
        """
        Low-level fetch of weather data from catalog, taking Level 8 tile and version as input
        """
        key = (version, tile8)

        if key in self.partition_cache:
            weather_data = self.partition_cache[key]
        else:
            if self.verbose:
                print("Reading weather catalog tile,version",tile8,version)
            weather_part = self._layer[region].read_partitions([tile8],version)
            weather_blob = list(weather_part)
            if len(weather_blob) > 0:
                weather_data = self._schema[region].decode_blob(weather_blob[0])
            else:
                weather_data = None
            self.partition_cache[key] = weather_data #cache the results for subsequent lookups
        return weather_data

    def decode_precip(self, ptype):
        """Decode the precip enum into a human-readable string"""
        name = ptype.DESCRIPTOR.fields_by_name['precipitation_type'].enum_type.values_by_number[ptype.precipitation_type].name
        return name[0]+name[1:].lower()  # decapitalize except the first letter

    def get_weather(self, latitude, longitude, timestamp=None, version=None):
        """
        Fetch weather based on coordinate and either timestamp (datetime) or catalog version number
        """
        # quick determination of NA or Europe
        if longitude < -37.0:  # North America
            region = 'NA'
        else:  # Europe
            region = 'EU'

        if (version is None) and (timestamp is not None):
            version = self._timestamp_decoder.find_version(timestamp,region)
        elif (version is not None) and (timestamp is not None):
            assert False, 'do not provide both a version and a timestamp!'

        if version is None:  # this is our flag for "version not found...give up"
            return None
        tile8 = tile_id_from_coordinate(Point(latitude=latitude, longitude=longitude), 8)
        tile14 = tile_id_from_coordinate(Point(latitude=latitude, longitude=longitude), 14)

        weather_data = self._get_weather(tile8, version, region)

        if weather_data is None:
            return None  # no coverage

        output = {}
        for weather_tile in weather_data.weather_condition_tile:
            if str(weather_tile.tile_id) == str(tile14):
                #print(weather_tile)
                output['temperature'] = weather_tile.air_temperature.value
                if output['temperature'] < -5000:
                    return None  # no coverage

                output['humidity'] = weather_tile.humidity.value
                output['iop'] = weather_tile.iop.value
                output['visibility'] = weather_tile.visibility.value
                output['precip_type'] = self.decode_precip(weather_tile.precipitation_type)
                #if vis>16.0:
                #    vis = 'unlimited'
                #else:
                #    vis = '%.0f' %(vis)
                output['wind_speed'] = weather_tile.wind_velocity.value
                output['wind_direction'] = weather_tile.wind_velocity.direction
                output['pressure'] = weather_tile.air_pressure.value
                output['timestamp']=weather_tile.timestamp
        return output


def get_weather_for_tiles():
    """
    Thrown together quickly to handle the use case of 'extract all of the weather for a set of L14 tiles'
    over a few days
    """
    # easiest thing to do is to

    tsr = WeatherTimestampReader()
    v1 = tsr.find_version(datetime.datetime(2019,2,1,1,0,0),'EU')
    wr = WeatherReader()

    slices = []

    nversions = 3*24*4

    tiles = ['23618409','23618408','23618365','23618359','23618402','23618403','23618401','23618400','23618357']
    #for each tile get all of the l14 tiles, and the center lat/lon of each
    for version in range(v1,v1+nversions):
        print('version:',version)
        for tile in tiles:
            bbox = bounding_box_from_tile_id(tile)
            tiles14 = tile_ids_from_bounding_box(bbox,14)
            for t14 in tiles14:
                #print(version,tile,t14)
                c = bounding_box_from_tile_id(t14).center()
                weather = wr.get_weather(c.latitude,c.longitude,version=version)
                weather['latitude']=c.latitude
                weather['longitude']=c.longitude

                slices.append(weather)

            #sys.exit(1)
    df = pd.DataFrame.from_records(slices)
    df.to_csv('weather.csv',index=False)


if __name__=='__main__':
    #wr = WeatherReader()
    #print( wr.get_weather(38.914768, -76.989731,datetime.datetime(2019,7,4,13,0,0)) )
    get_weather_for_tiles()
