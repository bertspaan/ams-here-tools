"""
For now this contains all classes related to HMC access. In the future I may want
to split this file into multiple files.

The user will (mostly?) interact with the classes:
    HmcPartition
    TopologySegment
These provide access to methods that logically relate to the properties of a partition
and segment, respectively.

The actual data access, and in-memory caching, is performed by the classes:
    TopologyGeometry
    RoadAttributes
    NavigationAttributes
    TrafficPatterns
    LiveTrafficFlow
These in turn inherit from low-level classes:
    HmcAccess
    TrafficAccess
which inherit from CatalogAccess

I will use int for HMC partition IDs and segment IDs (instead of the OLP standard strings)
Convert to string only when i need to acccess the actual HMC content

Some misc notes:
- my old RibInterface did everything with python primitive types. Maybe this is a bit too simplistic
in the long term. (Too many convoluted nested data structures -- dicts of dicts of dicts...)
However I have started resorting to that again here, so maybe I haven't been able to improve...

Some items for potential improvement:
    In my zeal to make this a nested class-based structure instead of a single giant class, I ended up with some common
    functions getting repeated. Now I am trying to fix that with flatten_fclike().
    It is possible that some other code can be removed and replaced with calls to flatten_fclike().
    This is to be investigated.

    Initially I only implemented segment.property(offset = X) returning a single value
    Now I started adding segment.property(offset = None) returning a list of (start,end,value)
    The latter can be very useful.
    I have not implemented it universally though.

"""

import math
import sys
import time
from typing import Tuple

import nagini

from . import offset


def id2int(s: str) -> int:
    """
    Convert an OLP identifier like here:cm:segment:12345 to just the integer 12345 portion
    """
    return int(s.split(':')[-1])


def get_start_end(sa) -> Tuple[float, float]:
    """
    Convert a raw segmentAnchor sa from protobuf into a (start,end) offset as float (or int)
    """

    # It is not clear to me how nagini handles the default (non-existent) offsets now
    # Does it already return 0.0 and 1.0?
    # No matter what it does, this code will work
    if sa.HasField("first_segment_start_offset"):
        start = sa.first_segment_start_offset.value
    else:
        start = 0

    if sa.HasField("last_segment_end_offset"):
        end = sa.last_segment_end_offset.value
    else:
        end = 1

    return start, end


# basically this is synonymous with getattr(item, attr) but decodes enums in addition
# item is a protobuf object
def decode_enum(item, attr):
    """
    For enums stored in the protobuf, nagini returns the enum index, not the corresponding String
    This is annoying -- in most cases the user wants the meaningful string and not the enum value

    The automatic translation to string is possible but convoluted so we do it here.

    In case attr is not a reference to an enum this method is equivalent to getattr()
    """
    attr_value = getattr(item, attr)

    # I think this test works to detect an enum versus a non-enum but some testing ought to be done
    if (attr in item.DESCRIPTOR.fields_by_name):
        if item.DESCRIPTOR.fields_by_name[attr].enum_type is not None:  # new addition to the enum detection logic
            attr_value = item.DESCRIPTOR.fields_by_name[attr].enum_type.values_by_number[attr_value].name
    return attr_value


def get_road_attribute(layer_accessor, offset, orientation, attribute, pid, sid):
    """
    Generic accessor for attributes; use orientation='ignore' to indicate not to match on orientation
    CANNOT handle inverted segments
    layer_accessor object must implement get_data() method

    If None is passed for offset, will return an array of (start offset, end offset, value) instead of a single value
    """

    output = []
    for p in layer_accessor.get_data(attribute, pid, sid):
        sa, val = p
        if (orientation == 'ignore') or (decode_enum(sa, 'attribute_orientation') == orientation):
            start, end = get_start_end(sa)

            if offset is None:
                output.append((start, end, val))
            elif (offset >= start) and (offset <= end):
                return val

    if offset is None:
        # sort by start offset
        return sorted(output)
    return None


# this function is generic to the attributes that
# have schema like Functional Class
# |-- functional_class: array (nullable = true)
# |    |-- element: struct (containsNull = true)
# |    |    |-- segment_anchor_index: array (nullable = true)
# |    |    |    |-- element: integer (containsNull = true)
# |    |    |-- functional_class: string (nullable = true)
# where the attribute value is represented by the same name as the attribute itself
# Using the sub_attr_name argument one can specify a different name for the inner attribute name
# Also it requires that oriented-segment-reference list is length 1
def flatten_fclike(data, attribute, parsed, anchors, pid, sub_attr_name=None):
    # originally implemented for the RoadAttributes class ; however the logic
    # is needed by many RIB layers, so the function needs to exist outside that class to avoid code duplication
    # (maybe suggests that a separate class for each layer is dumb, but I'll stick with it for now)

    # we want to allow for multiple calls to this method for different sub_attr_name values with the same attribute name
    # e.g. attribute='speed_limit' and sub_attr_name of value and then source
    # so we need to key the cache dict using something unique -> a combination of attribute and sub_attr_name
    if sub_attr_name is None:
        sub_attr_name = attribute
        key = attribute
    else:
        key = attribute + ":" + sub_attr_name

    data[pid][key] = {}  # key is segment id

    attrlist = getattr(parsed, attribute)
    for item in attrlist:

        attr_value = decode_enum(item, sub_attr_name)

        sai_list = item.segment_anchor_index
        for sai in sai_list:
            anchor = anchors[sai]
            assert len(anchor.oriented_segment_ref) == 1, 'flatten_fclike wrong length of osr list'
            segid = id2int(anchor.oriented_segment_ref[0].segment_ref.identifier)
            if segid not in data[pid][key]:
                data[pid][key][segid] = []
            # just store the unadulterated segment_anchor
            # this is a list because there can be more than one segment anchor per segment
            data[pid][key][segid].append((anchor, attr_value))
    return data


# ##### want to have the highest reuse of code possible
#      (least code duplication)
# here we've got just the definition of the olp resource
# and a generic function for reading and parsing one partition of data
# from a versioned or volatile catalog
# We don't define which catalog here because this function can be shared between
# RIB and other catalogs
class CatalogAccess:
    # this OLP resource is a class variable and thus will be shared by every child of this class
    _olp = nagini.resource('olp')

    # this could just be a function defined outside the class, but I would like to keep it
    # inside the class to keep it more "hidden"
    @staticmethod
    def read_data(layer, schema, pid, version):

        tries_left = 5
        isbad = False
        while tries_left>0:

            try:
                pblobs = list(layer.read_partitions([str(pid)], version))
            except:
                #FIXME printing the layer is not useful here because it is an object
                print('Exception reading partition',layer,pid)
                time.sleep(1)
                tries_left -= 1
                continue

            if len(pblobs) > 0:
                pblob = pblobs[0]
            else:
                print('failure getting data',layer, pid)
                tries_left -= 1
                time.sleep(1)
                continue

            try:
                parsed = schema.decode_blob(pblob)
                # print('         success decoding blob',pid) #for debugging
            except:  # FIXME catch actual exception types...
                print('unexpected error decoding blob',layer, pid)
                tries_left -= 1
                time.sleep(1)
                continue

            return parsed
        print("reading data from OLP FAILED")
        return None

"""
Each catalog that we're going to access needs a class that inherits from CatalogAccess.
The catalog HRN and nagini catalog object is a class variable so that it is shared between instances.
Here we have access classes for the HMC and Traffic.
In weather.py we have a similar class for Weather
"""


# inherit from CatalogAccess and define the catalog to be HMC (RIB-2)
class HmcAccess(CatalogAccess):
    _catalog_hrn = 'hrn:here:data:::rib-2'
    _catalog = CatalogAccess._olp.catalog_by_hrn(_catalog_hrn)
    _hmc_version = None  # or a hard-coded version if desired ; default to latest version

    # layer is a nagini layer and schema is a nagini schema ; pid is an integer
    # access the catalog and use the schema to decode the data
    # FIXME better error handling tbd
    # I did not have a good plan for leading underscores in method names. To be improved.
    def _read_data(self, layer, schema, pid):
        return super().read_data(layer, schema, pid, self._hmc_version)


class TrafficAccess(CatalogAccess):
    _catalog_hrn = 'hrn:here:data:::olp-traffic-1'
    _catalog = CatalogAccess._olp.catalog_by_hrn(_catalog_hrn)

    # set version=None because there are no versioned layers in this catalog (volatile only)
    def _read_data(self, layer, schema, pid):
        return super().read_data(layer, schema, pid, None)


"""
Now define classes for parsing the data pulled from the OLP catalogs.
There is one class per layer.

These classes will also implement crude data caches such that once a partition is read from OLP,
the data is kept in memory indefinitely.
"""


class LiveTrafficFlow(TrafficAccess):
    _data = {}
    _layer_id = 'traffic-flow'
    _layer = TrafficAccess._catalog.layer_by_id(_layer_id)
    _schema = _layer.read_schema()

    # For volatile layers, the concept of having a cache is a little more ugly:
    # The data is not persistent even at the source so the idea of keeping it
    # cached locally is dubious.
    # However I still think that the overhead of accessing the data on OLP will be high
    # so i think a local cache is still justified for a short running job
    # Maybe even desirable from the perspective of data consistency...

    def _load_data(self, pid):
        if pid in self._data:
            #print("\t\tLiveTrafficFlow cache hit",pid)
            return

        #print("\t\tLiveTrafficFlow cache miss",pid)
        #print("\t\t\tkeys 1:",list(self._data.keys()))
        parsed = super()._read_data(self._layer, self._schema, pid)

        # in the zeppelin code i did not do a "flattening" like i did for RIB data
        # i just filled the cache like this
        self._data[pid] = parsed


class TopologyGeometry(HmcAccess):
    # Some of the implementation is copied from curv_utils.py

    # key is partition id ; value is dict of segment IDs mapping to data itself
    _data = {}  # somewhat poorly named ; this is the segment data
    _pidlookup = {}  # for Segment ID -> Partition lookups
    _nodedata = {}  # key is PID; points to a dict of nodeID -> Node Data

    _layer_id = 'topology-geometry'
    # this is, i believe, the correct (and only?) syntax for this
    _layer = HmcAccess._catalog.layer_by_id(_layer_id)
    _schema = _layer.read_schema()

    def _load_data(self, pid):
        """
        Load data from the cache or, if not in the cache, from OLP
        This should not be called by the user.
        Instead every method called by the user should call this method as a first step
        """
        if pid in self._data:
            #print("\t\tTopologyGeometry cache hit",pid)
            return
        self._data[pid] = {}
        self._nodedata[pid] = {}
        #print("\t\tTopologyGeometry cache miss",pid)

        parsed = super()._read_data(self._layer, self._schema, pid)

        segment_data = parsed.segment
        # this is an iterable of type Segment
        # we want to store the data for access that avoids loops
        # so we want a dict (pid,sid) -> segment data

        for seg in segment_data:
            sidI = id2int(seg.identifier)

            # the segment protobuf doesn't really need any "flattening" or other manipulation
            # just store it in the cache without any manipulation
            self._data[pid][sidI] = seg
            self._pidlookup[sidI] = pid

        node_data = parsed.node
        for n in node_data:
            nid = id2int(n.identifier)
            # only store the segment ref list
            # ### question for my data model...do I construct TopologySegments here?
            #     or do i just keep the partition,segment id in tuples?
            #     for now i will stick with tuples
            self._nodedata[pid][nid] = [(int(q.partition_name), id2int(q.identifier)) for q in n.segment_ref]

    def get_shape_points(self, pid, sid, fmt='tuples'):
        """
        Return the shape points (including nodes) for the segment.
        Return type depends on fmt:
            'tuples' -> list of tuples of (lat, lon)
        """
        # i am leaving myself flexibility to return other formats here, for instance a list of nagini Point instead of
        # plain tuple, or even geoJson
        self._load_data(pid)
        output = None
        if sid in self._data[pid]:
            if fmt == 'tuples':
                output = [(q.latitude, q.longitude) for q in self._data[pid][sid].geometry.point]

        return output

    def get_node(self, pid, sid, index) -> Tuple[int, int]:
        """
        Fetch start/end nodes of a segment as (partition, node ID) pair; index=0 means start, 1 means end
        """
        self._load_data(pid)
        assert index in [0, 1], 'illegal node index'
        if sid in self._data[pid]:
            if index == 0:
                n = self._data[pid][sid].start_node_ref
            elif index == 1:
                n = self._data[pid][sid].end_node_ref
            return int(n.partition_name), id2int(n.identifier)

    # Not clear if this should be implemented here or as a method of a Node class
    # I will just do it here
    def get_connected_segments(self, pid, nid):
        """
        For the given node, return a list of connected segments as List[TopologySegment]
        """
        self._load_data(pid)
        if nid in self._nodedata[pid]:
            # not clear if it is better to stick to plain IDs or construct the TopologySegment objects
            return [TopologySegment(q[0], q[1]) for q in self._nodedata[pid][nid]]

    def get_shared_node(self, pid1, sid1, pid2, sid2):
        """
        Given 2 segments, return the node (pid, nid) shared by the segments
        """
        self._load_data(pid1)
        self._load_data(pid2)

        # try all 4 combinations of orientations for 2 joined segments
        for which_node1 in [0, 1]:
            for which_node2 in [0, 1]:
                if (self.get_node(pid1, sid1, which_node1) == self.get_node(pid2, sid2, which_node2)):
                    return self.get_node(pid1, sid1, which_node1)

        # in case the segments don't intersect
        return None

    def get_shared_node2(self, pid1, sid1, sid2):
        """
        Given 2 segments, return the node (pid, nid) shared by the segments
        This is an alternative implementation that does not require knowing the partition ID of segment 2
        """
        sid1node1 = self.get_node(pid1, sid1, 0)
        sid1node2 = self.get_node(pid1, sid1, 1)

        for inode in [sid1node1, sid1node2]:
            connected_segments = self.get_connected_segments(inode[0], inode[1])
            if sid2 in [q.sid for q in connected_segments]:
                return inode  # (pid,nid)
        return None

    def get_segment_length(self, pid, sid) -> float:
        """
        Get segment length
        """
        self._load_data(pid)

        if sid in self._data[pid]:
            return self._data[pid][sid].length
        return None

    def get_all_segment_ids(self, pid):
        """
        Given a Partition ID, get a list of all segment IDs
        """
        self._load_data(pid)

        data = self._data[pid]
        return list(data.keys())

    def translate_segments(self, pid, sid, seglist):
        """
        Input: segment ID list [123,456,789,987,654] where the partition is known only for an arbitrary ID in the list
        Output:  [(pid1,123),(pid2,456),(pid3,789),etc]

        Not likely to be needed by the average user but needed internally for interpreting live traffic data
        """
        N = len(seglist)
        output = [None] * N

        i0 = seglist.index(sid)
        # put known result into output
        output[i0] = (pid, sid)

        # go forward from known result to the end of the list
        for i in range(i0 + 1, N):
            the_pid = output[i - 1][0]
            the_sid = output[i - 1][1]
            adjacent_partition = self.get_partition_for_adjacent_segment(the_pid, the_sid, seglist[i])
            output[i] = (adjacent_partition, seglist[i])

        # now go backward from known result to beginning of list
        for i in range(i0 - 1, -1, -1):
            the_pid = output[i + 1][0]
            the_sid = output[i + 1][1]
            adjacent_partition = self.get_partition_for_adjacent_segment(the_pid, the_sid, seglist[i])
            output[i] = (adjacent_partition, seglist[i])
        return output

    def get_partition_for_adjacent_segment(self, pid, sid, sid2):
        """
        in case we know the pId,sId for one segment,
           and the sId of an adjacent segment, but do NOT know the partition for that adjacent segment
        This method will determine and return that unknown partition Id
        """
        shared_node = self.get_shared_node2(pid, sid, sid2)
        if shared_node is None:
            raise ValueError("In get_partition_for_adjacent_segment: shared_node is None")
        connected_segs = self.get_connected_segments(shared_node[0], shared_node[1])
        for seg in connected_segs:
            if sid2 == seg.sid: #seg[1]:
                return seg.pid #seg[0]
        return None


class TrafficPatterns(HmcAccess):
    _data = {}  # key is partition -> attribute -> dict of segments
    _layer_id = 'traffic-patterns'
    _layer = HmcAccess._catalog.layer_by_id(_layer_id)
    _schema = _layer.read_schema()

    def _load_data(self, pid):
        if pid in self._data:
            return
        self._data[pid] = {}  # key is attribute, then segment ID

        # read the data from OLP
        parsed = super()._read_data(self._layer, self._schema, pid)
        anchors = parsed.segment_anchor
        self._flatten_trafficpatterns(parsed, anchors, pid)

    def _flatten_trafficpatterns(self, parsed, anchors, pid):
        attribute = 'traffic_pattern'
        self._data[pid][attribute] = {}  # key is segment id

        attrlist = getattr(parsed, attribute)
        for item in attrlist:
            # fetch all of the data for this pattern
            pattern = getattr(item, attribute)
            sai_list = item.segment_anchor_index
            for sai in sai_list:
                anchor = anchors[sai]
                assert len(anchor.oriented_segment_ref) == 1, 'load_accessible_data wrong length of osr list'
                segid = id2int(anchor.oriented_segment_ref[0].segment_ref.identifier)
                if segid not in self._data[pid][attribute]:
                    self._data[pid][attribute][segid] = []
                self._data[pid][attribute][segid].append((anchor, pattern))


class NavigationAttributes(HmcAccess):
    _data = {}  # key is partition -> attribute -> dict of segments
    _layer_id = 'navigation-attributes'
    _layer = HmcAccess._catalog.layer_by_id(_layer_id)
    _schema = _layer.read_schema()

    def _load_data(self, pid):
        # check if data is already loaded
        if pid in self._data:
            return
        self._data[pid] = {}  # key is attribute, then segment ID

        # read the data from OLP
        parsed = super()._read_data(self._layer, self._schema, pid)
        anchors = parsed.segment_anchor

        # for attributes in this layer, flatten the data into an easier to access format
        self._flatten_traveldirection(parsed, anchors, pid)
        flatten_fclike(self._data, 'speed_category', parsed, anchors, pid)

    def get_data(self, attribute, pid, sid):
        """
        Return list of data for the requested attribute for the requested segment
        Return empty list if there is no match
        """
        assert attribute in ['travel_direction', 'speed_category'], 'get_data (NavigationAttributes): incorrect attribute: '+attribute
        self._load_data(pid)
        if sid in self._data[pid][attribute]:
            return self._data[pid][attribute][sid]
        return []

    def _flatten_traveldirection(self, parsed, anchors, pid):
        attribute = 'travel_direction'
        self._data[pid][attribute] = {}  # key is segment id
        attrlist = getattr(parsed, attribute)

        for item in attrlist:
            sai_list = item.segment_anchor_index
            for sai in sai_list:
                # travel direction is weird in that there is no attribute value
                anchor = anchors[sai]
                assert len(anchor.oriented_segment_ref) == 1, '_flatten_fclike wrong length of osr list'
                segid = id2int(anchor.oriented_segment_ref[0].segment_ref.identifier)
                if segid not in self._data[pid][attribute]:
                    self._data[pid][attribute][segid] = []
                self._data[pid][attribute][segid].append(anchor)


class AdvancedNavigationAttributes(HmcAccess):
    _data = {}  # key is partition -> attribute -> dict of segments
    _layer_id = 'advanced-navigation-attributes'
    _layer = HmcAccess._catalog.layer_by_id(_layer_id)
    _schema = _layer.read_schema()

    def _load_data(self, pid):
        # check if data is already loaded
        if pid in self._data:
            return
        self._data[pid] = {}  # key is attribute, then segment ID

        # read the data from OLP
        parsed = super()._read_data(self._layer, self._schema, pid)
        anchors = parsed.segment_anchor

        # for attributes in this layer, flatten the data into an easier to access format
        flatten_fclike(self._data, 'speed_limit', parsed, anchors, pid, 'value')  # extract only the value from speed limit

    def get_data(self, attribute, pid, sid):
        """
        Return list of data for the requested attribute for the requested segment
        Return empty list if there is no match
        """
        assert attribute in ['speed_limit:value'], 'get_data (AdvancedNavigationAttributes): incorrect attribute: '+attribute
        self._load_data(pid)
        if sid in self._data[pid][attribute]:
            return self._data[pid][attribute][sid]
        return []


class RoadAttributes(HmcAccess):
    _data = {}  # key is partition -> attribute -> dict of segments
    _layer_id = 'road-attributes'
    _layer = HmcAccess._catalog.layer_by_id(_layer_id)
    _schema = _layer.read_schema()

    def _load_data(self, pid):
        # check if data is already loaded
        if pid in self._data:
            return
        self._data[pid] = {}  # key is attribute, then segment ID

        # read the data from OLP
        parsed = super()._read_data(self._layer, self._schema, pid)

        # note: we have no choice but to read the whole partition of the road-attributes layer
        # (of course if we were using OMA this would be somewhat different)
        # so parse anything that might be of interest!
        # of course the tradeoff there is we're going to take the time to parse,
        # and the memory to store, everything in the partition/layer whether we care
        # about it or not

        # as a future optimization maybe we can make that optional

        anchors = parsed.segment_anchor
        flatten_fclike(self._data, 'functional_class', parsed, anchors, pid)
        flatten_fclike(self._data, 'iso_country_code', parsed, anchors, pid)
        self._flatten_accessibleby(parsed, anchors, pid)

    def get_data(self, attribute, pid, sid):
        """
        Return list of data for the requested attribute for the requested segment
        Return empty list if there is no match
        """
        assert attribute in ['functional_class', 'accessible_by', 'iso_country_code'], 'get_data: incorrect attribute: '+attribute
        self._load_data(pid)
        if sid in self._data[pid][attribute]:
            return self._data[pid][attribute][sid]
        return []

    # boilerplate except the attr_value line
    def _flatten_accessibleby(self, parsed, anchors, pid):
        attribute = 'accessible_by'
        self._data[pid][attribute] = {}
        attrlist = getattr(parsed, attribute)
        for item in attrlist:
            # there are lots of attributes: autos, motor cycles, etc
            # this is NOT an enum so this syntax is ok
            attr_value = getattr(item, 'applies_to')  # this contains all of them

            sai_list = item.segment_anchor_index
            for sai in sai_list:
                anchor = anchors[sai]
                assert len(anchor.oriented_segment_ref) == 1, '_flatten_accessibleby wrong length of osr list'
                segid = id2int(anchor.oriented_segment_ref[0].segment_ref.identifier)
                if not segid in self._data[pid][attribute]:
                    self._data[pid][attribute][segid] = []
                self._data[pid][attribute][segid].append((anchor, attr_value))


"""
Define the "user-facing" classes:
    HmcPartition
    TopologySegment
These abstract away, to some extent, the fact that there are all of these different layers for the HMC (and related) data
Instead just give the user a segment object and have that class implement accessors for all of the properties that
segments can have.

These classes instantiate and call the classes defined above as needed.
Because the nagini data access and my data caches are class variables, they will between
all instances of each class.
"""


# remains to be seen "how needed" this class is
# maybe it is just a wrapper around TopologyGeometry
# or maybe there is more than 1 layer that we'll want properties of a partition for
# and then this will provide a nice abstraction
class HmcPartition:
    def __init__(self, pid):
        self.pid = pid

    def get_all_segment_ids(self):
        """
        return a list of segment Ids for all segments in the partition
        """
        topo = TopologyGeometry()
        return topo.get_all_segment_ids(self.pid)


class TopologySegment:
    """
    Top level user access for segments and their properties
    """
    # do not store data in this class ; instead go fetch data from the
    # classes that represent layers ; those classes load data from OLP and cache it
    def __init__(self, pid, sid):
        self.pid = pid
        self.sid = sid

    def __eq__(self, other):
        return (self.pid == other.pid) and (self.sid == other.sid)

    def __str__(self):
        s = str(self.pid) + ':' + str(self.sid)
        return s

    def length(self):
        """Return segment length"""
        tg = TopologyGeometry()
        return tg.get_segment_length(self.pid, self.sid)

    def start_node(self):
        """Return (pid, nid) of start node"""
        tg = TopologyGeometry()
        return tg.get_node(self.pid, self.sid, 0)

    def end_node(self):
        """Return (pid, nid) of end node"""
        tg = TopologyGeometry()
        return tg.get_node(self.pid, self.sid, 1)

    def _get_road_attribute_BFB(self, offset, orientation, attribute):
        """
        generic accessor for attributes, use orientation='ignore' to indicate not to match on orientation
        CANNOT handle inverted segments
        """
        ra = RoadAttributes()
        return get_road_attribute(ra, offset, orientation, attribute, self.pid, self.sid)

    def _get_road_atttribute_BOTH(self, offset, attribute):
        """generic accessor for attributes that always use orientation BOTH"""
        return self._get_road_attribute_BFB(offset, 'ignore', attribute)

    def functional_class(self, offset):
        """Return functional class"""
        return self._get_road_atttribute_BOTH(offset, 'functional_class')

    def country_code(self, offset):
        """Return ISO country code"""
        cc = self._get_road_atttribute_BOTH(offset, 'iso_country_code')
        if cc is not None:
            return decode_enum(cc, 'official_country_code')
        return None

    def speed_category(self, offset):
        """Return Speed Category"""
        na = NavigationAttributes()
        return get_road_attribute(na, offset, 'ignore', 'speed_category', self.pid, self.sid)

    def speed_limit(self, offset, direction):
        """Return speed limit"""
        ana = AdvancedNavigationAttributes()
        return get_road_attribute(ana, offset, direction, 'speed_limit:value', self.pid, self.sid)

    def live_traffic_info(self, rib_offset, my_orient='any'):  # ,attribute='traffic-flow'
        """
        For the given position on the segment,
        Return the Live Traffic info
        """
        # This code in zeppelin was also able to handle traffic incidents ; requires work to reach that stage here
        flow = LiveTrafficFlow()
        flow._load_data(self.pid)

        thedata = flow._data[self.pid]

        if thedata is None:
            return None

        segment_index = self.sid

        tg = TopologyGeometry()

        # this is copied as closely as possible from the original zeppelin notebook
        # but some adjustments are needed because nagini exposes the protobuf datatypes more than zeppelin did
        output = []
        i = 0
        for item in thedata.items:
            topo_seg_id_list = list(item.topology_segment.topology_segment_id)

            if segment_index in topo_seg_id_list:
                trafitem_dd = item.topology_segment.is_first_segment_in_driving_direction
                # case: traffic item is exactly 1 segment long
                if len(topo_seg_id_list) == 1:
                    rib_dd = self.travel_direction(rib_offset)
                    access_flag = self.accessible_by(rib_offset)

                    if (trafitem_dd and (rib_dd == 'BOTH' or rib_dd == 'FORWARD')) or (
                            (not trafitem_dd) and rib_dd == 'BACKWARD'):
                        if (rib_offset >= item.topology_segment.start_offset) and (
                                rib_offset <= 1.0 - item.topology_segment.end_offset):
                            if (my_orient == 'any' or (trafitem_dd and my_orient == 'FORWARD')):
                                output.append(item)
                            elif ((not trafitem_dd) and my_orient == 'BACKWARD'):
                                output.append(item)
                    elif ((not trafitem_dd) and (rib_dd == 'BOTH' or rib_dd == 'FORWARD')) or (
                            trafitem_dd and rib_dd == 'BACKWARD'):
                        if (rib_offset >= item.topology_segment.end_offset) and (
                                rib_offset <= 1.0 - item.topology_segment.start_offset):
                            if (my_orient == 'any' or ((not trafitem_dd) and my_orient == 'BACKWARD')):
                                output.append(item)
                            elif (trafitem_dd and my_orient == 'FORWARD'):
                                output.append(item)
                    else:
                        assert False, 'ERROR in 1-segment TrafficItem logic. This should not happen'
                # case: trafficItem is at least 3 segments, and our segment is in the middle (i.e. not the beginning or the end)
                elif (len(topo_seg_id_list) > 2) and (segment_index != topo_seg_id_list[0]) and (
                        segment_index != topo_seg_id_list[-1]):
                    this_segment_i = topo_seg_id_list.index(segment_index)
                    # careful - index here means segment number e.g. here:cm:segment:123456789
                    adjacent_segment_index = topo_seg_id_list[this_segment_i - 1]
                    # adjacent_segment_id = "here:cm:segment:"+str(adjacent_segment_index)
                    shared_node_id = tg.get_shared_node2(self.pid, segment_index,
                                                         adjacent_segment_index)  # returns (pid,nodeId) pair
                    in_dd_456 = (shared_node_id == self.start_node())
                    if my_orient == 'any':
                        output.append(item)
                    elif in_dd_456 and (my_orient == 'FORWARD'):
                        output.append(item)
                    elif (not in_dd_456) and (my_orient == 'BACKWARD'):
                        output.append(item)
                # case: our segment is the first segment in the list
                elif (len(topo_seg_id_list) >= 2) and (segment_index == topo_seg_id_list[0]):
                    if trafitem_dd and (my_orient in ['any', 'FORWARD']):
                        if rib_offset >= item.topology_segment.start_offset:
                            output.append(item)
                    elif (not trafitem_dd) and (my_orient in ['any', 'BACKWARD']):
                        if (1.0 - rib_offset) >= item.topology_segment.start_offset:
                            output.append(item)
                # case: our segment is the last segment in the list
                elif (len(topo_seg_id_list) >= 2) and (segment_index == topo_seg_id_list[-1]):
                    adjacent_segment_index = topo_seg_id_list[-2]
                    # adjacent_segment_id = "here:cm:segment:"+str(adjacent_segment_index)
                    shared_node_id = tg.get_shared_node2(self.pid, segment_index,
                                                         adjacent_segment_index)  # returns (pid,nodeId) pair

                    dd_aligned = (shared_node_id == self.start_node())
                    if dd_aligned:
                        if rib_offset <= (1.0 - item.topology_segment.end_offset):
                            if my_orient in ['any', 'FORWARD']:
                                output.append(item)
                    else:
                        if rib_offset >= item.topology_segment.end_offset:
                            if my_orient in ['any', 'BACKWARD']:
                                output.append(item)

                else:
                    assert False, 'ERROR in finding correct TrafficItem.'
        return output

    def get_offset_on_trafitem(self, trafitem_segment_info, rib_offset):
        """
        Utility for converting between coordinate systems
        For the given rib_offset on this segment, and the segment info from a traffic item,
        Return the offset on the traffic item
        """

        tg = TopologyGeometry()

        # first step is to convert trafitem_segment_info.topology_segment_id list to list of (partition_id, segment id)
        seglist1 = list(trafitem_segment_info.topology_segment_id)
        # step 1: convert to pid,sid pairs
        trafitem_segments = tg.translate_segments(self.pid, self.sid, seglist1)

        # convert pid,sid pairs to objects
        trafitem_segment_objs = [TopologySegment(q[0], q[1]) for q in trafitem_segments]
        segment_lengths = [q.length() for q in trafitem_segment_objs]

        length_traveled = 0.0

        for idx, trafitem_segment in enumerate(trafitem_segment_objs):
            this_length = segment_lengths[idx]

            # could maybe make this equality test more elegant but this should do
            if (trafitem_segment.pid == self.pid) and (
                    trafitem_segment.sid == self.sid):  # (part_id,seg_id): #this is the segment we're looking for
                if idx == 0:
                    # account for start_offset and rib_offset
                    in_dd = trafitem_segment_info.is_first_segment_in_driving_direction
                    if in_dd:
                        L0 = (rib_offset - trafitem_segment_info.start_offset) * this_length
                    else:
                        L0 = ((1.0 - rib_offset) - trafitem_segment_info.start_offset) * this_length
                else:  # only need to account for rib_offset
                    # this is a bit ugly -- used TopologySegment objects in the first half but the raw pid,sid info in the second half
                    shared_node = tg.get_shared_node(trafitem_segment.pid, trafitem_segment.sid,
                                                     trafitem_segments[idx - 1][0], trafitem_segments[idx - 1][1])
                    in_dd = (shared_node == trafitem_segment.get_start_node())
                    if in_dd:
                        L0 = rib_offset * this_length
                    else:
                        L0 = (1.0 - rib_offset) * this_length
                length_traveled += L0
                break
            elif idx == 0:
                L0 = this_length * (1.0 - trafitem_segment_info.start_offset)
                length_traveled += L0
            else:
                # this is not the segment we're looking for, and it is somewhere in the middle of the trafficItem
                length_traveled += this_length

        # now what is the total length of the trafficItem
        if len(trafitem_segments) == 1:
            trafitem_length = ((1.0 - trafitem_segment_info.end_offset) - trafitem_segment_info.start_offset) * \
                              segment_lengths[0]
        elif len(trafitem_segments) == 2:
            trafitem_length = (1.0 - trafitem_segment_info.start_offset) * segment_lengths[0]
            trafitem_length += (1.0 - trafitem_segment_info.end_offset) * segment_lengths[1]
        else:
            trafitem_length = (1.0 - trafitem_segment_info.start_offset) * segment_lengths[0]
            trafitem_length += (1.0 - trafitem_segment_info.end_offset) * segment_lengths[-1]
            for i in range(1, len(segment_lengths) - 1):
                trafitem_length += segment_lengths[i]

        trafitem_offset = length_traveled / trafitem_length
        # print('DEBUG TrafficItem Offset',length_traveled,trafitem_length,trafitem_offset) #debug
        return trafitem_offset

    # again, i'm going to try to change as little of this as possible from zeppelin and just hope it still works
    def get_live_traffic_speed(self, rib_offset, rib_orient):
        """
        fetch the live traffic and return (timestamp, update time, live speed)
        """
        debug = False

        # exactly what should be returned can evolve ; stick with convention that we return primitive python types
        # for now return a tuple of timestamp,update timestamp, live average speed
        the_live_traffic_info = self.live_traffic_info(rib_offset, rib_orient)
        if debug:
            print('the_live_traffic_info', the_live_traffic_info)
            print(len(the_live_traffic_info))
        if len(the_live_traffic_info) == 0:
            return None
        elif len(the_live_traffic_info) > 1:
            bad_ids = [q.id for q in the_live_traffic_info]
            print('WARNING in get_live_traffic_speed; there are too many matches (will just use the first one)',
                  len(the_live_traffic_info), self.pid, self.sid, rib_orient, rib_offset, bad_ids)

        info = the_live_traffic_info[0]
        if debug:
            print('list item 1', info)
        timestamp = info.created_timestamp
        update = info.updated_timestamp
        flow = info.flow
        speed = None
        if flow is not None:
            flow_segments = list(flow.segment)
            if debug:
                print('flow_segments', flow_segments)
            if len(flow_segments) == 1:
                if (flow_segments[0] is not None) and (flow_segments[0].speed is not None):
                    speed = flow_segments[
                        0].speed.average_speed_kph  # or .free_flow_speed_kph or whatever data member is desired
                # disable this warning for now ; seems to usually just indicate that traversability_status is CLOSED
                # else:
                #    print("WARNING - flow segment is missing:",info)
            elif len(flow_segments) > 1:  # some of this might need revisiting for transition from zeppelin ; not sure if "is None" tests still work
                # print('There are multiple flow segments!')
                # print(info)
                offset_on_trafitem = self.get_offset_on_trafitem(info.topology_segment, rib_offset)
                # print('Offset on TrafficItem:',offset_on_trafitem)
                for ifs in range(len(flow_segments)):
                    if (flow_segments[ifs] is None) or (flow_segments[ifs].speed is None):
                        # see note above about disabling the warning
                        # print("WARNING - flow segment is missing:",info)
                        continue
                    so = flow_segments[ifs].start_offset
                    if ifs + 1 == len(flow_segments):
                        eo = 1.0
                    else:
                        eo = flow_segments[ifs + 1].start_offset
                    if offset_on_trafitem >= so and offset_on_trafitem <= eo:
                        # print("Flow segment found:",ifs)
                        speed = flow_segments[ifs].speed.average_speed_kph
                        break
        return (timestamp, update, speed)

    def traffic_pattern(self, offset, direction):
        """
        Return the traffic pattern object for the segment
        """
        # i honestly do not know if offset matters
        # i.e. does a single segment ever have more than one pattern?
        tp = TrafficPatterns()
        tp._load_data(self.pid)

        output = []
        if self.sid in tp._data[self.pid]['traffic_pattern']:
            for p in tp._data[self.pid]['traffic_pattern'][self.sid]:
                sa, pattern = p
                start, end = get_start_end(sa)
                # note that if we want to match to FORWARD, BACKWARD strings we need
                # to use decode_enum() to get the string version of the attribute_orientation
                if decode_enum(sa, 'attribute_orientation') == direction:
                    if offset is None:
                        output.append((start, end, pattern))
                    elif (offset >= start) and (offset <= end):
                        return pattern
        if offset is None:
            return output
        return None

    def decode_tpinfo(self, tpinfo, my_epoch, day_index):
        my_speed = None
        isdone = False
        for item in tpinfo:
            # do not decode the enum into a string
            # OLP has enum=1 mean SUNDAY
            # subtracting 1 means 0->SUNDAY
            day_of_week = item.day_of_week - 1

            if (day_of_week == day_index):
                for pattern in item.speed_pattern:

                    # for the first pattern, put it into my_speed right away
                    if my_speed is None:
                        my_speed = pattern.speed

                    # print(pattern)
                    if my_epoch < pattern.epoch:
                        isdone = True
                        break
                    my_speed = pattern.speed
            if isdone:  # just saves a little time
                break

        # print('speed',my_speed)
        return my_speed

    #STARTED IMPLEMENTING THIS BUT DIDN'T FINISH (or test)....
    def expand_tpinfo(self, tpinfo, day_index):
        pat = []

        for item in tpinfo:
            # OLP has enum=1 mean SUNDAY
            # subtracting 1 means 0->SUNDAY

            day_of_week = item.day_of_week - 1
            if day_of_week == day_index:
                for pattern in item.speed_pattern:
                    pat.append(pattern.epoch, pattern.speed)
        return pat


    # Higher-level function than traffic_pattern() --
    # calls traffic_pattern and further interprets the result
    # ONLY handles 7-day patterns for now
    def get_historical_traffic_speed(self, offset, orientation, local_time, return_type='speed'):
        """
        Return historical traffic speed for this segment at time local_time

        return_type can be:
        speed -- return integer speed at local_time
        1day -- return pattern for the entire day of local_time (NOT YET IMPLEMENTED!)
        """
        # local_time should be a datetime
        tpinfo = self.traffic_pattern(offset, orientation)
        if tpinfo is None:
            return None
        elif (offset is None) and (len(tpinfo) == 0):
            return []

        my_epoch = int(math.floor((local_time.hour * 60 + local_time.minute + local_time.second / 60.0) / 5))
        # print("my_epoch",my_epoch)

        day_index = local_time.weekday() + 1  # weekday() returns 0 for monday
        if day_index == 7:  # fix sunday
            day_index = 0

        output = []
        # print("day_index",day_index)
        if offset is None:
            for tpsubinfo in tpinfo:
                #each tpsubinfo is a (start, end, tpinfo)
                if return_type=='speed':
                    output.append( (tpsubinfo[0], tpsubinfo[1], self.decode_tpinfo(tpsubinfo[2], my_epoch, day_index)) )
        else:
            if return_type=='speed':
                return self.decode_tpinfo(tpinfo, my_epoch, day_index)
        if return_type=='speed':
            return sorted(output)

    def travel_direction(self, offset):
        """
        Return the travel direction
        """
        na = NavigationAttributes()
        for sa in na.get_data('travel_direction', self.pid, self.sid):
            start, end = get_start_end(sa)
            # slightly tricky -- the attribute_orientation is an enum
            # that is hard to naively understand without decoding it to string
            o = decode_enum(sa, 'attribute_orientation')

            # i can't remember the exact motivation for this ;
            # is it just in the interest of being as exact as possible,
            #  or is it really needed in some edge case?
            if (offset >= start) and ((offset < end) or (offset == end and (end == 1))):
                return o
        return None

    def accessible_by(self, offset, which='automobiles'):
        """
        returns whether the segment is accessible by the class of vehicles specified in the 'which' arugment
        """
        ra = RoadAttributes()

        for p in ra.get_data('accessible_by', self.pid, self.sid):
            sa, val = p
            start, end = get_start_end(sa)
            if (offset >= start) and (offset <= end):
                return getattr(val, which)
        return None

    def shape_points(self):
        """Return shape points as tuples"""
        tg = TopologyGeometry()
        return tg.get_shape_points(self.pid, self.sid, 'tuples')

    def point_from_offset(self, offset0):
        """Given an offset, return the coordinate along the segment as a tuple of (lat, lon)"""
        p = offset.get_latlng_from_link_offset(self.shape_points(), offset0)
        return p

    def get_offset(self, coord):
        """Given (lat, lon) return the offset"""
        return offset.get_offset(self.shape_points(), coord[0], coord[1])

    def shape_points_between_offsets(self, o1, o2):
        """Given 2 offsets, return all of the shape points in between them"""
        sp = self.shape_points()
        offs = [self.get_offset(q) for q in sp]

        out = []
        for o, p in zip(offs, sp):
            if (o >= o1) and (o <= o2):
                out.append(p)

        return out

    def shape_points_as_joined_string(self):
        """Convenience function for getting output suitable for copy/paste to Dongwook's web viewer"""
        # arguably this should not be a method of this class but rather a generally available convenience function
        # that takes a list of tuples as input and does the one-liner implemented here
        sp = self.shape_points()
        return ','.join([str(q[0])+','+str(q[1]) for q in sp])

# END of class definitions
# ### quasi-tests are down here


def main():
    pid = 23611529

    offset = 0.5

    print("=== 1")
    p1 = HmcPartition(pid)
    all_segment_ids = p1.get_all_segment_ids()
    print("=== 2")
    for iseg, seg in enumerate(all_segment_ids):
        segment = TopologySegment(pid, seg)
        aa = segment.accessible_by(offset)
        fcstring = segment.functional_class(offset)
        dot = segment.travel_direction(offset)
        segment_length = segment.length()
        print(seg, "\t", fcstring, aa, dot, segment_length)
        # sys.exit(1)


def tr():
    s = TopologySegment(20095971, 457683118)
    # p = s.traffic_pattern(0.5,"BACKWARD")
    # sp = s.get_historical_traffic_speed(0.5,"BACKWARD",datetime.datetime.now() )#datetime.datetime(2019,11,15,17,15,0)
    # print(sp)
    lt = s.get_live_traffic_speed(0.5, 'BACKWARD')
    print('live output:', lt)


def shape1():
    s = TopologySegment(20095971, 457683118)
    print( s.shape_points_as_joined_string() )


def country_code():
    s = TopologySegment(20095971, 457683118)
    print( s.country_code(0.5) )


def speed_cat():
    s = TopologySegment(20095971, 457683118)
    print(s.speed_category(0.5))


def interp():
    s = TopologySegment(20095971, 457683118)
    print( s.point_from_offset(0.1) )
    print( s.point_from_offset(0.5) )
    print( s.point_from_offset(0.9) )

def dump_attributes():
    offset = 0.5

    p1 = HmcPartition(20097302)
    for sid in p1.get_all_segment_ids():
        s = TopologySegment(p1.pid, sid)

        aa = s.accessible_by(offset)
        if not aa:
            continue
        td = s.travel_direction(offset)
        sc = s.speed_category(offset)

        if td=='BOTH':
            sl = s.speed_limit(offset, 'FORWARD')
        else:
            sl = s.speed_limit(offset, td)

        fc = s.functional_class(offset)

        print(sid, td, sc, sl, fc)

if __name__ == '__main__':
    # main()
    #speed_cat()
    #dump_attributes()
    interp()
