# HMC Tools
This package provides classes for accessing HERE Map Content, Traffic, and Weather using the HERE Python SDK.

OLP access is via nagini. Notable python packages that need to be installed:

`$ pip install PyGeodesy`

To install (from `hmcpkg`):

`$ pip install -e .`

### Detailed instructions
Create a new virtual environment with the OLP SDK for Python. Here I clone an existing one:

`$ conda create --name olp-sdk-for-python-0.6.0-test1 --clone olp-sdk-for-python-0.6.0-env`

`$ conda activate olp-sdk-for-python-0.6.0-test1`

Clone this repository to your preferred location e.g. `~/code/`.

Change to `hmcpkg`:

`$ cd ~/code/python-sdk-utilities/hmcpkg`

Install

`$ pip install -e .`

Test:

```bash
$ cd
$ python
```

```python
>>> from hmctools import segment
>>> s1 = segment.TopologySegment(20096362, 397200490)
>>> s1.speed_category(0.3)
'BTW_71_90_KMPH__41_54_MPH'
```