import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="hmctools", # Replace with your own username
    version="0.0.1",
    author="Joshua Thompson",
    author_email="joshua.thompson@here.com",
    description="Classes to facilitate access to HERE Map Content, Traffic, and Weather",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://main.gitlab.in.here.com/olp/customer-solutions/data-science/internal/python-sdk-utilities",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
